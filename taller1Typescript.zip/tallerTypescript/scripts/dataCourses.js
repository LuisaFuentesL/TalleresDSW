import { Course } from './course.js';
export var dataCourses = [
    new Course("Desarrollo de SW en equipo", "Rubby Casallas", 3),
    new Course("Sistemas transaccionales", "Claudia Jiménez", 3),
    new Course("Diseño y análisis de algoritmos", "Ruben Manrique", 3),
    new Course("Biología Celular", "Jesus Uribe", 3),
    new Course("TI en las organizaciones", "Disney Rubiano", 3),
    new Course("Laboratorios de maratones de programación", "Nicolas Cardozo", 1),
    new Course("Robots del hoy y del mañana", "Carlos Rodriguez", 2),
    new Course("Softbol", "Jose Aguirre", 1)
];
